var checker = require('./checker');
// It seems that a friend has given you a book to read.
// But unfortunately the book has been given to you in reverse.
// You will have to use your JavaScript skills to reverse it back to normal and read it 

//1.You will have to call ReadBookFile function from the checker object that will read the book.txt file for you in string format.
//2.You will have to use your brain to reverse the text from the file back to normal.
//3.If you want to check if your answer is correct you can call the CheckText function from the checker object that will tell you if you are right or wrong.
//Remember to have fun :).
